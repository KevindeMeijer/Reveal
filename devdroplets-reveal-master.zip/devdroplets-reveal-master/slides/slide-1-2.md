### Stacking
With `.r-stack` stacks keeps code as seperate blocks.


<div class='r-stack'>

```jsx
// This is a singular file
const hello = 'world'

// Open with codepen -->
```
<!-- .element: class="fragment fade-in-then-out"  -->


```jsx
// This is another file
const foo = console.log('oh noh?')

// Open with codepen -->
```
<!-- .element: class="fragment fade-in-then-out"  -->

</div>