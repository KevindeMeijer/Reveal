### Git Emoji :sparkles:

Emojis :smile: everywhere :flushed:

[List of Emoji :page_facing_up:](https://www.webfx.com/tools/emoji-cheat-sheet/)