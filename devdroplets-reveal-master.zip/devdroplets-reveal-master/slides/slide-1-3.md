### Stacking
With `.code-stack` merges all the code upon codepen.


<div class='code-stack'>

```jsx
// This is a singular file
const hello = 'world'

// No codepen button
```
<!-- .element: class="fragment fade-in-then-out"  -->


```jsx
// This is the same file
const foo = console.log('oh noh?')

// Open merged code in codepen -->
```
<!-- .element: class="fragment fade-in-then-out"  -->

</div>