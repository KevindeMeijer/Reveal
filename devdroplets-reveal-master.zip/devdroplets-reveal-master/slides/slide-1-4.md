### Codeblocks
With `.no-codepen` have no codepen button.


```jsx
// This is a singular file
const hello = 'world'

// Removed codepen
```
<!-- .element: class="no-codepen"  -->
